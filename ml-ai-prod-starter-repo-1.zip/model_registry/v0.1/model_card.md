# Model Card (v0.1)
- **Intended Use:** Movie recommendation (educational project)
- **Training Data:** MovieLens snapshot
- **Metrics:** HR@K, NDCG@K (offline); Online KPI proxy
- **Limitations:** Synthetic/academic setup; fairness/security risks discussed in report