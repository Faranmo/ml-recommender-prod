def test_features_placeholder():
    assert True